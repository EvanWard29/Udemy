@extends('layouts.app')

@section('content')
    <h1 class="text-center">Page Unavailable</h1>
@stop