# Blogs

This application is a Blog Posting service that allows users to create an account and create new blog posts for users to read and comment on.
**This application is not inteded to be fully functional and is merley a demonstartion of the power of Laravel.**

Application Website: http://ec2-13-40-60-49.eu-west-2.compute.amazonaws.com

*This application follows a tutorial by Edwin Diaz on Udemy: https://www.udemy.com/share/101WCu3@cl__39_d6k2rZHxSv2cT_BUfKFA1j4fUzkpyEh24GxonH-grzCb65AHnDC76bPLS_Q==/*