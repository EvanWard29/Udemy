<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Upload Media</h1>

    <?php echo Form::open(['method'=>'POST', 'action'=>'AdminMediaController@store', 'files'=>true, 'class'=>'dropzone']); ?>

        <div class="form-group">
            <?php echo Form::label('photo_id', 'Photo:'); ?>

            <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Upload Media', ['class'=>'btn btn-primary']); ?>

        </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>