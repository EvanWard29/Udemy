<?php $__env->startSection('content'); ?>

    <h1>Posts</h1>

    <table class="table">
        <thead>
            <tr>
                <th>Post ID</th>
                <th>Photo</th>
                <th>User</th>
                <th>Category</th>
                <th>Title</th>
                <th>Body</th>
                <th>Created</th>
                <th>Updated</th>
            </tr>
        </thead>
        <tbody>
            <?php if($posts): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($post->id); ?></td>
                        <td><img height="50" src="<?php echo e($post->photo ? $post->photo->file : 'http://placehold.jp/400x400.png'); ?>" alt=""></td>
                        <td><a href="<?php echo e(route('posts.edit', $post->id)); ?>"><?php echo e($post->user->name); ?></a></td>
                        <td><?php echo e($post->category ? $post->category->name : 'Uncategorised'); ?></td>
                        <td><?php echo e($post->title); ?></td>
                        <td><?php echo e($post->body); ?></td>
                        <td><?php echo e($post->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($post->updated_at->diffForHumans()); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>