<?php $__env->startSection('content'); ?>
    <h1>Edit Todo</h1>

    <?php echo Form::model($todo, ['method'=>'PUT', 'action'=>['TodosController@update', $todo->id]]); ?>

        <div class='form-group'>
            <?php echo Form::label('text', 'Title:'); ?>

            <?php echo Form::text('text', null, ['class'=>'form-control']); ?>

        </div>
        <div class='form-group'>
            <?php echo Form::label('body', 'Task:'); ?>

            <?php echo Form::textarea('body', null, ['class'=>'form-control']); ?>

        </div>
        <div class='form-group'>
            <?php echo Form::label('due', 'Due:'); ?>

            <?php echo Form::date('due', null, ['class'=>'form-control']); ?>

        </div>
        <div class='form-group'>
            <?php echo Form::submit('Save', ['class'=>'btn btn-primary']); ?>

        </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>