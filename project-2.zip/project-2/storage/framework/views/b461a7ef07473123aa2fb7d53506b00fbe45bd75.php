<?php $__env->startSection('content'); ?>
    <?php use Carbon\Carbon; $due = Carbon::parse($todo->due); ?>
    <a href="<?php echo e(route('todo.index')); ?>" class="btn btn-default">Go Back</a>

    <h1><?php echo e($todo->text); ?></h1>
    <div class="badge <?php echo e($due->lt(new Carbon()) ? 'bg-danger' : 'bg-info'); ?>"><?php echo e($diff_browserLocale); ?></div>
    <div class="badge bg-primary"><?php echo e($date_local); ?></div>

    <!-- Date in US or UK format sent from server -->
    <div class="badge <?php echo e($due->lt(new Carbon()) ? 'bg-danger' : 'bg-info'); ?>"><?php echo e($date_12); ?></div>

    <!-- Date in US or UK format sent from server -->
    <div class="badge <?php echo e($due->lt(new Carbon()) ? 'bg-danger' : 'bg-info'); ?>"><?php echo e($date_24); ?></div>
        
    <hr>

    <p><?php echo e($todo->body); ?></p>

    <a href="<?php echo e(route('todo.edit', $todo->id)); ?>" class="btn btn-primary">Edit</a>
    
    <?php echo Form::open(['method'=>'DELETE', 'class'=>'pull-right', 'action'=> ['TodosController@destroy', $todo->id]]); ?>

        <div class='form-group'>
            <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>

        </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>